read me!
please make sure to install these libraries by using cmd
pip install pandas
pip install selenium
pip install DateTime
pip install openpyxl

make sure to put geckodriver on the program folder
geckodriver:https://github.com/mozilla/geckodriver/releases/download/v0.30.0/geckodriver-v0.30.0-win64.zip
make sure to install firefox last update.
